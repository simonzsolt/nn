SET SESSION AUTHORIZATION 'p-nouve';

SET search_path = "backup", pg_catalog;

-- Definition

-- DROP TABLE "backup"."t_jiaozhu_bkp";
CREATE TABLE "backup"."t_jiaozhu_bkp" (
    "jiaozhu" character varying(200)
) WITHOUT OIDS;

