SET SESSION AUTHORIZATION 'p-nouve';

SET search_path = "backup", pg_catalog;

-- Definition

-- DROP TABLE "backup"."versek_bkp";
CREATE TABLE "backup"."versek_bkp" (
    "m_index" integer,
    "incipit" character varying(255)
) WITHOUT OIDS;

